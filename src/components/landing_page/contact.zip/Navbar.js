import React, { useState } from "react";
import styled from "styled-components";
import logo from "../../assets/logo.png";
import { GiHamburgerMenu } from "react-icons/gi";
import { VscChromeClose } from "react-icons/vsc";
import { useNavigate} from 'react-router-dom'
export default function Navbar() {

  const navigate=useNavigate();
    const [navbarState, setNavbarState] = useState(false);
  return (
    <div style={{ "backgroundColor":"#e9eeef;","height": "15vh", "overflowY": "auto" }}>
      
      <Nav style={{ "position": 'fixed', "top": "0", left: 0, width: '100%', backgroundColor: '#f3ede3' }}>
       
                            <div class="col-md-10 col-sm-8 col-8 " style={{"font-family":"noto-sans","marginTop":"-94px"}}>
                             <a class="phone text-info" style={{"text-decoration":"none","font-weight":"bold"}}>
								 <span class="fa fa-phone ml-2 p-2 text-secondary" ></span>8530676768|9764931818 </a>
            <a class="phone text-info" style={{"text-decoration":"none","font-weight":"bold"}}>
                <span class="fa fa-envelope ml-2 p-2 text-secondary"> | </span> maharashtrainformatics@gmail.com</a>
            <a class="phone text-info" style={{"text-decoration":"none","font-weight":"bold"}}><span> | </span>Reg No : U63122PN2023OPC221703</a>

                          

                            {/* <div class="col-md-2 col-sm-4 col-4">

                                <a href="login.php" class="btn btn-danger btn-md ">
                                    <span class="fa fa-sign-in"></span>&nbspMeSK Login</a>
                            </div> */}
                            
                           
                        
                        
                        

                    </div>
        <div className="brand">
          
          <div className="container" style={{marginRight:"10","height":"123px" ,"backgroundColor":"e9eeef"}}>
           
            <img src={logo} alt="" style={{"height":"80px","width":"200px","marginLeft":"-2169px"}} />
            {/* <a  style={{"marginTop":"-94px","fontFamily":"serif","fontSize":"small","marginLeft":"-141px"}} href=""><span class=" ml-2 p-2 ">maharashtrainformatics@gmail.com</span></a>
            <a style={{"fontSize":"small","marginTop":"-94px"}} >Reg No :U63122PN2023OPC221703</a>
         
            <a style={{"fontSize":"small","marginTop":"-38px"}}> <span class="fa fa-phone ml-2 p-2 text-secondary" ></span>8530676768|9764931818 </a> */}
            
          </div>
          <div className="toggle">
            {navbarState ? (
              <VscChromeClose onClick={() => setNavbarState(false)} />
            ) : (
              <GiHamburgerMenu onClick={() => setNavbarState(true)} />
            )}
          </div>
        </div>

        <ul style={{"marginLeft":" -425px"}}>
          <li>
            <a href="#home">Home</a>
          </li>
          <li>
            <a href="#services">About</a>
          </li>
          <li>
            <a href="#recommend">Places</a>
          </li>
          <li>
            <a href="#contact">Contact Us</a>
          </li>
        </ul>
        <button onClick={()=>navigate(`${process.env.PUBLIC_URL}/login`)} style={{background:"rgb(255 0 0)"}}>
        MeSK Login</button>
      </Nav>
      <ResponsiveNav state={navbarState}>
        <ul>
          <li>
            <a href="#home" onClick={() => setNavbarState(false)}>
              Home
            </a>
          </li>
          <li>
            <a href="#services" onClick={() => setNavbarState(false)}>
              About
            </a>
          </li>
          <li>
            <a href="#recommend" onClick={() => setNavbarState(false)}>
              Places
            </a>
          </li>
          <li>
            <a href="#contact" onClick={() => setNavbarState(false)}>
              Contact Us
            </a>
          </li>
          
        </ul>
      </ResponsiveNav>
    </div>
  );
}

{/* Your scrollable content container */}
{/* <div className="scrollable-container" style={{ height: '100vh', overflowY: 'auto' }}>
  {/* Your fixed div */}



const Nav = styled.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  .brand {
    .container {
      cursor: pointer;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 0.4rem;
      font-size: 1.2rem;
      font-weight: 900;
      text-transform: uppercase;
    }
    .toggle {
      display: none;
    }
  }
  ul {
    display: flex;
    gap: 1rem;
    list-style-type: none;
    li {
      a {
        text-decoration: none;
        color: black;
        font-size: 1.2rem;
        transition: 0.1s ease-in-out;
        &:hover {
          color: #ff6262;
        }
      }
      &:first-of-type {
        a {
          color: #ff6262;
          font-weight: 900;
        }
      }
    }
  }
  button {
    padding: 0.5rem 1rem;
    cursor: pointer;
    border-radius: 1rem;
    border: none;
    color: white;
    background-color: #48cae4;
    font-size: 1.1rem;
    letter-spacing: 0.1rem;
    margin-right: 54px;
    text-transform: uppercase;
    &:hover {
      background-color: #eb0f0f;;
    }
  }
  @media screen and (min-width: 280px) and (max-width: 1080px) {
    .brand {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      .toggle {
        display: block;
      }
    }
    ul {
      display: none;
    }
    button {
      display: none;
    }
  }
`;

const ResponsiveNav = styled.div`
  display: flex;
  position: absolute;
  z-index: 1;
  top: ${({ state }) => (state ? "50px" : "-400px")};
  background-color: white;
  height: 30vh;
  width: 100%;
  align-items: center;
  ul {
    list-style-type: none;
    width: 100%;
    li {
      width: 100%;
      margin: 1rem 0;
      margin-left: 2rem;

      a {
        text-decoration: none;
        color: #0077b6;
        font-size: 1.2rem;
        
        &:hover {
          color: #023e8a;
        }
      }
      &:first-of-type {
        a {
          color: #023e8a;
          font-weight: 900;
        }
      }
    }
  }
`;
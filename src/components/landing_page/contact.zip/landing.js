import React, { useEffect } from "react";
import Footer from "./Footer";
import Hero from "./Hero";
import Navbar from "./Navbar";
import Land from "./land";
import Recommend from "./Recommend";
import ScrollToTop from "./ScrollToTop";
import Services from "./Services";
import Testimonials from "./Testimonials";
import Contact from "./contact";
// import { Route,Routes } from 'react-router-dom';

const Landing = () => {
  return (
    <>
      <ScrollToTop />
      <Navbar />
      <Hero />
      <Services />
      <Land />
      <Recommend />
      <Testimonials />
      <Contact />
      <Footer />
    </>
  );
};

export default Landing;

import React from "react";
// import Layout from "./../components/Layout/Layout";
// import SupportAgentIcon from "@mui/icons-material/SupportAgent";
// import MailIcon from "@mui/icons-material/Mail";
// import CallIcon from "@mui/icons-material/Call";
import "./location.css"
// import {
//   Box,
//   Paper,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Typography,
// } from "@mui/material";

const Contact = () => {
  return (
    <>



  <div class="container">
    <div class="row">
      <div class="col-sm" id="contact" data-aos="fade-up-right" >
        <h2 class=" new-head" >CONTACT US</h2>
        <h2 class="head-line-gold"></h2>
        <p class=" time1"  style={{"fontSize":"1rem"}}>Please enter the details below to get in touch with us !</p>
      {/* <form action="https://formsubmit.co/socioghost.office@gmail.com" method="POST"> 
         */}
<form style={{"marginLeft":"303px"}} >
        <div class="form-group">
          <div class="input-group">
           <div class="input-group-addon">
            <i class="fas fa-user"></i>
            </div>
          <input  class="form-control"  type="text" id="name" name="name" placeholder=" Name" autocomplete="off" required style={{"fontSize":"1rem"}}/>
          </div>
        </div>

        <div class="form-group ">
          <div class="input-group">
           <div class="input-group-addon">
            <i class="fas fa-envelope-square"></i>
            </div>
          <input  class="form-control" type="text" id="phone" name="phone" placeholder="Phone No." pattern="[789][0-9]{9}" autocomplete="off" required style={{"fontSize":"1rem"}}/>
          </div>
      </div>


      <div class="form-group ">
        <div class="input-group">
         <div class="input-group-addon">
           <i class="fas fa-envelope-square"></i>
          </div>
        <input  class="form-control" type="text" id="mail" name="email" placeholder="Email Id"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" autocomplete="off" required style={{"fontSize":"1rem"}}/>
		
        </div>
        <br/>
      </div>
							  <input type="hidden" name="_subject" value="New submission Contact Us form Mantra Magnifique !"/>
							  <input type="hidden" name="_next" value="http://mantramagnifique.socioghost.com/thankyou.html"/>
                              <input type="hidden" name="_captcha" value="false"/>
                              <input type="hidden" name="_template" value="table"/>
        <button type="submit" style={{"width": "102px",
    "height": "50px",
   "background":" #bd872d"}} >Submit</button>
</form> 
<div style={{"textAlign":"center"}}>
        <h5 style={{"margin-top": "40px","fontSize":"1rem"}}>Site Address</h5>
        <br/>
        <span   style={{"text-align":" left"}}>आमचा ऑफिस पत्ता:</span>
            <h5 style={{"margin-top":" 19px"}}>Maharashtra informatics Pvt Ltd, Sonigara classic building, D12 , Opp Trinity high school, Vitthalwadi, Akurdi Pune 411035</h5>  
            {/* <p  >The Metropole, 3rd Floor, Next to INOX, Bund Garden Road, Camp Pune-411001<br/> 
        For Booking Call Us :  <a href="tel:+9145299927">9145299927</a>  </p>
		<p  > Project By <br/> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img Height="90" src="asset/iconM.jpeg"/><br/>
          <img src="images/mahaera.png"  Width="10%"/> MAHARERA Reg. No. P52100002674 
		  </p> */}
      </div>
      </div>
     
      <div class="col-sm"  data-aos="fade-up-left" style={{"background":" #7a6688","marginRight":"91px"}}>
            <h2 class=" new-head">LOCATION</h2><br/>
            {/* <!-- <img src="asset/location.jpg" width="100%"> --> */}
            <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3780.2264989442174!2d73.77673321489475!3d18.653829387331612!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMTjCsDM5JzEzLjgiTiA3M8KwNDYnNDQuMSJF!5e0!3m2!1sen!2sin!4v1690363172031!5m2!1sen!2sin" width="1247" height="450" style={{"border":"0"}} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
   
</div>
    </div>
  </div>



    </>
  );
};

export default Contact;
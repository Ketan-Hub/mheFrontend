import React from "react";
import styled from "styled-components";
import avatarImage from "../../assets/profile1.jpeg";
export default function Testimonials() {
  return (
    <Section id="testimonials">
      <div className="title">
        <h2 style={{"fontSize":"1rem","lineHeight":"3rem"}}>महाराष्ट्र ई-सेवा केंद्र हा उपक्रम प्रामाणिकपणे,लोकांच्या विश्वासास पात्र राहून पैसे कमविण्याचा एक चांगला पर्याय आहे. या व्यवसायातून समाजातील सर्वच स्तरातील अनेक समाजबांधवांशी संबंध येतो आणि त्यातून तुम्ही समाजाशी देखील जोडले जाता. तुमची स्वतःची एक ओळख निर्माण होते. आणि सहजपणे तुम्ही तुमच्या वेळेनुसार व्यवसाय करू शकता व सोईनुसार वाढवू शकता. महाराष्ट्र ई-सेवा केंद्र या उपक्रमातून तुम्ही लोकांना योग्य व कमी काळात चांगली सेवा दिली तर लोक तुमच्याकडे मोठ्या विश्वासाने पाहतात आणि तुमच्या व्यवसायास मोठे स्वरूप प्राप्त होते व तुम्हीच तुमच्या व्यवसायाचे मालक होता.त्याचे फायदेही खूप आहेत. जसे की आर्थिक स्वातंत्र्य.म्हणजे तुम्ही तुमच्या वेळेनुसार आर्थिक सोर्स निर्माण करू शकता.या व्यवसायात तुम्हाला वैयक्तिक कामाचे स्वातंत्र्य राहते. कामकाजाचे स्वातंत्र्य आणि अनेक फायदे ज्यांनी व्यक्तीचे जीवन अधिक अर्थपूर्ण बनते..</h2>
     
      </div>
      <div className="testimonials">
        <div className="testimonial">
         
          <div className="info">
            <img src={avatarImage} alt="" />
            <div className="details">
              <h4>Gorakh Bangar </h4>
              <span style={{"fontSize":"1rem"}}>CEO</span>
            </div>
          </div>
        </div>
       
       
      </div>
    </Section>
  );
}

const Section = styled.section`
  margin: 5rem 0;
  .title {
    text-align: center;
    margin-bottom: 2rem;
  }
  .testimonials {
    display: flex;
    justify-content: center;
    margin: 0 2rem;
    gap: 2rem;
    .testimonial {
      background-color: aliceblue;
      padding: 2rem;
      border-radius: 0.5rem;
      box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
      transition: 0.3s ease-in-out;
      &:hover {
        transform: translateX(0.4rem) translateY(-1rem);
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
      }
      .info {
        display: flex;
        justify-content: center;
        gap: 1rem;
        align-items: center;
        margin-top: 1rem;
        img {
         border-radius: 6rem;
    height: 13rem;
        }
        .details {
          span {
            font-size: 0.9rem;
          }
        }
      }
    }
  }
  @media screen and (min-width: 280px) and (max-width: 768px) {
    .testimonials {
      flex-direction: column;
      margin: 0;
      .testimonial {
        justify-content: center;
        .info {
          flex-direction: column;
          justify-content: center;
        }
      }
    }
  }
`;
import React from "react";
import styled from "styled-components";
import Slider from 'react-slick';
import image1 from "../../assets/Maha E Seva web desing.jpg";
import image2 from "../../assets/Maha E Seva web desing2.jpg";
// import image3 from "../assets/Banner 3.jpg";
// import image4 from "../assets/Banner 4.jpg";
// import Image5 from "../assets/profile2.jpg";
import './land.css';

// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";

export default function Land() {
  const data = [
    {
        profile: image1,
       
    },
    {
        profile: image2,
       
    },
   

]
const settings = {
  infinite: true,
  dots: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  lazyLoad: true,
  autoplay: true,
  autoplaySpeed: 2000,

};


  return (
  
 <div>
  
  <div className="tag">
                
            </div>
            <div className="imgslider">
                <Slider {...settings}>
                    {data.map((item) => (
                        <div key={item.id}>
                            <img src={item.profile} alt={item.profile} />
                        </div>
                    ))}
                </Slider>
            </div>
 </div>
   
  );
}

const Section = styled.section`
  position: relative;
  margin-top: 2rem;
  width: 100%;
  height: 100%;

  
`;

import React from "react";
import styled from "styled-components";
import Slider from 'react-slick';
import image1 from "../../assets/Banner 1.jpg";
import image2 from "../../assets/Banner 2.jpg";
import image3 from "../../assets/Banner 3.jpg";
import image4 from "../../assets/Banner 4.jpg";
import Image5 from "../../assets/profile2.jpg";
import './hero.css';

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export default function Hero() {
  const data = [
    {
        profile: image1,
       
    },
    {
        profile: image2,
       
    },
    {
      profile: image3,
     
  },
  {
    profile: image4,

},

]
const settings = {
  infinite: true,
  dots: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  lazyLoad: true,
  autoplay: true,
  autoplaySpeed: 2000,

};


  return (
  
 <div>
  
  <div className="tag" style={{"margindown":"50%"}}>
                
         
            <div className="imgslider" >
                <Slider {...settings}>
                    {data.map((item) => (
                        <div key={item.id}>
                            <img src={item.profile} alt={item.profile} />
                        </div>
                    ))}
                </Slider>
            </div>
 </div>





 <div class=" text-center">
        <h2 class="welcome" style={{"font-family":"noto-sans","font-weight":"bold"}} >
        Welcome to Maharashtra<span style={{"color":"red"}}> E</span>-Seva Kendra</h2>
        <h2 class=" welcome1" style={{"font-family":"noto-sans","font-weight":"bold"}}>
			<span >आजच सुरू करा महाराष्ट्र ई-सेवा केंद्र आणि बना हमखास आत्मनिर्भर..!</span>
			</h2>
    </div>


 </div>
   
  );
}

const Section = styled.section`
  position: relative;
  margin-top: 2rem;
  width: 100%;
  height: 100%;

`;
